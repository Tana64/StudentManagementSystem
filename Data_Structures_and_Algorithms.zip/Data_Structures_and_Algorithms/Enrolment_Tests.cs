﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;


namespace Data_Structures_and_Algorithms
{
    /// <summary>
    /// Provides test methods to validate the functionality of the Enrollment classes.
    /// </summary>
    public class Enrolment_Tests
    {
     
        

        /// <summary>
        /// Tests if an Enrollment object can be created successfully.
        /// </summary>
        public void TestEnrollmentObjectCreation()
        {
            try
            {
                
                var subject = new Subject();
                var enrollment = new Enrollment(DateTime.Now, "A", "Spring 2024", subject);
                Console.WriteLine("Test Passed: Enrollment object created successfully.");
            }
            catch (Exception ex)
            {
                Console.WriteLine($"Test Failed: Error during enrollment object creation - {ex.Message}");
            }
        }

        /// <summary>
        /// Tests the default constructor of the Enrollment class.
        /// </summary>
        public void TestDefaultEnrollment()
        {
            var defaultEnrollment = new Enrollment();

            if (defaultEnrollment.Grade == "Not Graded" &&
                defaultEnrollment.Semester == "Unknown Semester" &&
                defaultEnrollment.Subject != null)
            {
                Console.WriteLine("Test Passed: Default Enrollment object has correct default values.");
            }
            else
            {
                Console.WriteLine("Test Failed: Default Enrollment object values are incorrect.");
            }
        }

        /// <summary>
        /// Tests the ToString method of the Enrollment class.
        /// </summary>
        public void TestEnrollmentToString()
        {
            
            var subject = new Subject { SubjectName = "Data Structures" };
            var enrollment = new Enrollment(new DateTime(2024, 2, 1), "B+", "Fall 2024", subject);

            string expected = $"Enrolled: {new DateTime(2024, 2, 1).ToShortDateString()}, Grade: B+, Semester: Fall 2024,  Subject: Data Structures";

            if (enrollment.ToString() == expected)
            {
                Console.WriteLine("Test Passed: ToString() method returns correct format.");
            }
            else
            {
                Console.WriteLine($"Test Failed: ToString() method returned '{enrollment.ToString()}', expected '{expected}'.");
            }
        }
    }
}
