﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Data_Structures_and_Algorithms
{
    /// <summary>
    /// Provides test methods for verifying the functionality of the <see cref="Enrollment"/> class.
    /// </summary>
    public class Enrolment_Tests
    {
        /// <summary>
        /// Tests the creation of an <see cref="Enrollment"/> object with specific values.
        /// </summary>
        public void TestEnrollmentCreation()
        {
            var enrollment = new Enrollment(new DateTime(2024, 1, 15), "A", "Spring 2024");

            if (enrollment.DateEnrolled == new DateTime(2024, 1, 15) &&
                enrollment.Grade == "A" &&
                enrollment.Semester == "Spring 2024")
            {
                Console.WriteLine("Test Passed: Enrollment object created successfully with correct values.");
            }
            else
            {
                Console.WriteLine("Test Failed: Enrollment object values are incorrect.");
            }
        }

        /// <summary>
        /// Tests the default constructor of the <see cref="Enrollment"/> class to ensure it initializes with default values.
        /// </summary>
        public void TestDefaultEnrollment()
        {
            var defaultEnrollment = new Enrollment();

            if (defaultEnrollment.Grade == "Not Graded" &&
                defaultEnrollment.Semester == "Unknown")
            {
                Console.WriteLine("Test Passed: Default Enrollment object has correct default values.");
            }
            else
            {
                Console.WriteLine("Test Failed: Default Enrollment object values are incorrect.");
            }
        }

        /// <summary>
        /// Tests the <see cref="Enrollment.ToString"/> method to verify that it returns the correct formatted string.
        /// </summary>
        public void TestToStringMethod()
        {
            var enrollment = new Enrollment(new DateTime(2024, 2, 1), "B+", "Fall 2024");
            string expected = $"Enrolled: {new DateTime(2024, 2, 1).ToShortDateString()}, Grade: B+, Semester: Fall 2024";

            if (enrollment.ToString() == expected)
            {
                Console.WriteLine("Test Passed: ToString() method returns correct format.");
            }
            else
            {
                Console.WriteLine($"Test Failed: ToString() method returned '{enrollment.ToString()}', expected '{expected}'.");
            }
        }
    }
}
