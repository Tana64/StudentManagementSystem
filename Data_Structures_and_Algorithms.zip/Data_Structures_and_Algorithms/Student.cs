﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;


namespace Data_Structures_and_Algorithms
{
    /// <summary>
    /// Represents a student, inheriting from Person, with additional details.
    /// </summary>
    public class Student : Person
    {
        // Constants for default values
        private const string DEFAULT_STUDENT_ID = "NO ID";
        private const string DEFAULT_PROGRAM = "Uknown Program";
        private static readonly DateTime DEFAULT_REGISTRATION_DATE = DateTime.Now;


        /// <summary>
        /// Gets or sets the student's ID.
        /// </summary>
        public string StudentID { get; set; }

        /// <summary>
        /// Gets or sets the student's enrolled program.
        /// </summary>
        public string Program { get; set; }

        /// <summary>
        /// Gets or sets the date the student registered.
        /// </summary>
        public DateTime DateRegistered { get; set; }

        /// <summary>
        /// Gets or sets list of enrollments for the student
        /// </summary>
        public List<Enrollment> Enrollments { get; set; }

        /// <summary>
        /// Initializes a new instance of the <see cref="Student"/> class with default values.
        /// </summary>


        public Student() : this(DEFAULT_NAME, DEFAULT_EMAIL, DEFAULT_PHONE, new Address(), DEFAULT_STUDENT_ID, DEFAULT_PROGRAM, DEFAULT_REGISTRATION_DATE, new List<Enrollment>()) { }


        /// <summary>
        /// Initializes a new instance of the <see cref="Student"/> class with specified values.
        /// </summary>
        public Student(string name, string email, string phoneNumber, Address address, string studentID, string program, DateTime dateRegistered, List<Enrollment> enrollments)
            : base(name, email, phoneNumber, address)
        {
            StudentID = studentID;
            Program = program;
            DateRegistered = dateRegistered;
            Enrollments = enrollments ?? new List<Enrollment>();
        }

        public void Enroll(Subject subject, string semester)
        {
            Enrollments.Add(new Enrollment(DateTime.Now, "Not Graded", semester, subject));
        }


        /// <summary>
        /// Checks if two Student objects are equal based on their StudentID.
        /// </summary>
        /// <param name="obj">The object to compare with the current instance.</param>
        /// <returns>True if the Student objects have the same StudentID, otherwise false.</returns>
        public override bool Equals(object obj)
        {
            if (obj is Student otherStudent)
            {
                return this.StudentID == otherStudent.StudentID;
            }
            return false;
        }

        /// <summary>
        /// Overrides the GetHashCode method to generate a unique hash code for a Student object.
        /// Uses StudentID for efficient hashing.
        /// </summary>
        /// <returns>A unique integer representing the student's hash code.</returns>
        public override int GetHashCode()
        {
            return StudentID.GetHashCode();
        }

        /// <summary>
        /// Overloads the == operator to compare two Student objects.
        /// </summary>
        /// <param name="s1">First student.</param>
        /// <param name="s2">Second student.</param>
        /// <returns>True if the StudentID values are equal, otherwise false.</returns>
        public static bool operator ==(Student s1, Student s2)
        {
            if (ReferenceEquals(s1, s2)) return true;
            if (s1 is null || s2 is null) return false;
            return s1.StudentID == s2.StudentID;
        }

        /// <summary>
        /// Overloads the != operator to compare two Student objects.
        /// </summary>
        /// <param name="s1">First student.</param>
        /// <param name="s2">Second student.</param>
        /// <returns>True if the StudentID values are not equal, otherwise false.</returns>
        public static bool operator !=(Student s1, Student s2)
        {
            return !(s1 == s2);
        }

        /// <summary>
        /// Returns a string representation of the student details.
        /// </summary>
        public override string ToString()
        {
            return $"{base.ToString()}, StudentID: {StudentID}, Program: {Program}, Registered: {DateRegistered.ToShortDateString()}";
        }
    }
}
