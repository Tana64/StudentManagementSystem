﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Data_Structures_and_Algorithms
{
    public class Student : Person
    {
        private string studentID;
        private string program;
        private DateTime dateRegistered;
        private static int numStudents = 0;

        public string StudentID { get; set; }
        public string Program { get; set; }
        public DateTime DateRegistered { get; set; }

        // Default constructor
        public Student() : this("Unknown", "Unknown", "Unknown", new Address(), "0000000000", "Unknown", DateTime.Now) { }

        // All-arg constructor
        public Student(string name, string email, string phoneNumber, Address address, string studentID, string program, DateTime dateRegistered)
            : base(name, email, phoneNumber, address)
        {
            StudentID = studentID;
            Program = program;
            DateRegistered = dateRegistered;
            numStudents++;
        }

        // Method to Override the ToString method
        public override string ToString()
        {
            return $"{base.ToString()}, StudentID: {StudentID}, Program: {Program}, Registered: {DateRegistered.ToShortDateString()}";
        }

        // Method to get the number of students
        public static int NumStudents { get { return numStudents; } }

        // Override Equals method
        /// <summary>
        /// Checks if two Student objects are equal based on their properties.
        /// </summary>
        /// <param name="obj">The object to compare with the current object.</param>
        /// <returns>True if the objects are equal; otherwise, false.</returns>
        public override bool Equals(object obj)
        {
            if (obj == null || GetType() != obj.GetType())
                return false;

            Student other = (Student)obj;

            return base.Equals(other) &&
                   studentID == other.studentID &&
                   program == other.program &&
                   dateRegistered == other.dateRegistered;
        }

        // Implement GetHashCode based on properties
        /// <summary>
        /// Gets a hash code for this Student instance.
        /// </summary>
        /// <returns>A hash code for the current object.</returns>
        public override int GetHashCode()
        {
            unchecked
            {
                int hash = base.GetHashCode();

                // Use null coalescing operator to handle null values gracefully
                hash = hash * 23 + (studentID?.GetHashCode() ?? 0);
                hash = hash * 23 + (program?.GetHashCode() ?? 0);
                hash = hash * 23 + dateRegistered.GetHashCode();

                return hash;
            }
        }


        // Overload the == operator
        /// <summary>
        /// Compares two Student objects for equality.
        /// </summary>
        /// <param name="s1">The first student to compare.</param>
        /// <param name="s2">The second student to compare.</param>
        /// <returns>True if the students are equal; otherwise, false.</returns>
        public static bool operator == (Student s1, Student s2)
        {
            if (ReferenceEquals(s1, null)) return ReferenceEquals(s2, null);
            return Equals(s1, s2);
        }

        // Overload the != operator
        /// <summary>
        /// Compares two Student objects for inequality.
        /// </summary>
        /// <param name="s1">The first student to compare.</param>
        /// <param name="s2">The second student to compare.</param>
        /// <returns>True if the students are not equal; otherwise, false.</returns>
        public static bool operator !=(Student s1, Student s2)
        {
            return !(s1 == s2);
        }
    }
}

