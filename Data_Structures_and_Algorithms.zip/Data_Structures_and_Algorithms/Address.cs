﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Data_Structures_and_Algorithms
{
    /// <summary>
    /// Represents an address with details such as street number, street name, suburb, postcode, and state.
    /// </summary>
    public class Address
    {
        // Declaration of variables
        private string streetNum;
        private string streetName;
        private string suburb;
        private string postcode;
        private string state;

        /// <summary>
        /// Counter to track the number of address instances.
        /// </summary>
        private static int numAddresses = 0;

        /// <summary>
        /// Gets or sets the street number.
        /// </summary>
        public string StreetNum
        {
            get { return streetNum; }
            set { streetNum = value; }
        }

        /// <summary>
        /// Gets or sets the street name.
        /// </summary>
        public string StreetName
        {
            get { return streetName; }
            set { streetName = value; }
        }

        /// <summary>
        /// Gets or sets the suburb.
        /// </summary>
        public string Suburb
        {
            get { return suburb; }
            set { suburb = value; }
        }

        /// <summary>
        /// Gets or sets the postcode.
        /// </summary>
        public string Postcode
        {
            get { return postcode; }
            set { postcode = value; }
        }

        /// <summary>
        /// Gets or sets the state.
        /// </summary>
        public string State
        {
            get { return state; }
            set { state = value; }
        }

        /// <summary>
        /// Initializes a new instance of the <see cref="Address"/> class with default values.
        /// </summary>
        public Address() : this("Unknown", "Unknown", "Unknown", "0000", "Unknown") { }

        /// <summary>
        /// Initializes a new instance of the <see cref="Address"/> class with specified values.
        /// </summary>
        /// <param name="streetNum">The street number.</param>
        /// <param name="streetName">The street name.</param>
        /// <param name="suburb">The suburb name.</param>
        /// <param name="postcode">The postcode.</param>
        /// <param name="state">The state.</param>
        public Address(string streetNum, string streetName, string suburb, string postcode, string state)
        {
            StreetNum = streetNum;
            StreetName = streetName;
            Suburb = suburb;
            Postcode = postcode;
            State = state;
            numAddresses++;
        }

        /// <summary>
        /// Returns a string representation of the address.
        /// </summary>
        /// <returns>A formatted address string.</returns>
        public override string ToString()
        {
            return $"{StreetNum} {StreetName}, {Suburb}, {State} {Postcode}";
        }

        /// <summary>
        /// Gets the total number of address instances created.
        /// </summary>
        public static int NumAddresses
        {
            get { return numAddresses; }
        }
    }
}
