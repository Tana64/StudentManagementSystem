﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Data_Structures_and_Algorithms
{
    class Utility
    {
        /// <summary>
        /// Performs a linear search on an array to find the target element.
        /// </summary>
        /// <typeparam name="T">The type of elements in the array, which must implement IComparable.</typeparam>
        /// <param name="array">The array to search through.</param>
        /// <param name="target">The element to search for.</param>
        /// <returns>The index of the target element if found; otherwise, -1.</returns>
        public static int LinearSearchArray<T>(T[] array, T target) where T : IComparable<T>
        {
            for (int i = 0; i < array.Length; i++)
            {
                if (array[i].CompareTo(target) == 0)
                {
                    return i; // Return the index if found
                }
            }
            return -1; // Return -1 if the target is not found
        }

        /// <summary>
        /// Performs a binary search on a sorted array to find the target element.
        /// </summary>
        /// <typeparam name="T">The type of elements in the array, which must implement IComparable.</typeparam>
        /// <param name="array">The sorted array to search through.</param>
        /// <param name="target">The element to search for.</param>
        /// <returns>The index of the target element if found; otherwise, -1.</returns>
        public static int BinarySearchArray<T>(T[] array, T target) where T : IComparable<T>
        {
            int left = 0, right = array.Length - 1;

            while (left <= right)
            {
                int mid = left + (right - left) / 2;
                int comparison = array[mid].CompareTo(target);

                if (comparison == 0)
                {
                    return mid; // Target found
                }
                else if (comparison < 0)
                {
                    left = mid + 1; // Search in the right half
                }
                else
                {
                    right = mid - 1; // Search in the left half
                }
            }

            return -1; // Return -1 if the target is not found
        }
    }

}
