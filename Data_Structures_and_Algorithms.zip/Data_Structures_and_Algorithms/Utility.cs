﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Data_Structures_and_Algorithms
{
    public class Utility
    {
        /// <summary>
        /// Performs a linear search on an array to find the target element.
        /// </summary>
        /// <typeparam name="T">The type of elements in the array, which must implement IComparable.</typeparam>
        /// <param name="array">The array to search through.</param>
        /// <param name="target">The element to search for.</param>
        /// <returns>The index of the target element if found; otherwise, -1.</returns>
        /// 

        //Self-comments : Linear search is simple but slow when dealing with large data because it checks every element.

        //Loop through each element in the array.
    //Compare each element with the target.
      //If found, return the index.
	//If the loop finishes without finding the target, return -1

        public static int LinearSearchArray<T>(T[] array, T target) where T : IComparable<T>
        {
            // Loop through the array to find the target element
            for (int i = 0; i < array.Length; i++)
            {
                if (array[i].CompareTo(target) == 0) // If target is found
                {
                    return i; // Return the index where target is found
                }
            }
            return -1; // Return -1 if the target is not found
        }

        /// <summary>
        /// Performs a binary search on a sorted array to find the target element.
        /// </summary>
        /// <typeparam name="T">The type of elements in the array, which must implement IComparable.</typeparam>
        /// <param name="array">The sorted array to search through.</param>
        /// <param name="target">The element to search for.</param>
        /// <returns>The index of the target element if found; otherwise, -1.</returns>
        /// 

        //Self-Comments : Binary search is much faster than linear search but works only if the array is sorted.
        //	Find the middle element of the array.
	//If it's the target, return its index.
    //If the target is greater, search in the right half.
	//If the target is smaller, search in the left half.
	//Repeat until the target is found or the search space is empty

        public static int BinarySearchArray<T>(T[] array, T target) where T : IComparable<T>
        {
            int left = 0, right = array.Length - 1;

            // Loop until the search space is empty
            while (left <= right)
            {
                int mid = left + (right - left) / 2; // Find the middle index
                int comparison = array[mid].CompareTo(target);

                if (comparison == 0)
                {
                    return mid; // Target found at index mid
                }
                else if (comparison < 0)
                {
                    left = mid + 1; // Search in the right half
                }
                else
                {
                    right = mid - 1; // Search in the left half
                }
            }

            return -1; // Return -1 if target is not found
        }

        /// <summary>
        /// Sorts an array in ascending order using Bubble Sort.
        /// </summary>
        /// <typeparam name="T">The type of elements in the array, which must implement IComparable.</typeparam>
        /// <param name="array">The array to sort in ascending order.</param>
        /// 

        //Self-Comments : 1.	Compare two neighboring elements.
        //	Swap them if they are in the wrong order.
        //	Move to the next pair and repeat.
        //	Continue looping until the array is sorted.
        //Bubble Sort is simple but slow when sorting large data sets

        public static void BubbleSortAscending<T>(T[] array) where T : IComparable<T>
        {
            int n = array.Length;
            for (int i = 0; i < n - 1; i++)
            {
                for (int j = 0; j < n - 1 - i; j++) // Move largest element to the end
                {
                    if (array[j].CompareTo(array[j + 1]) > 0) // Swap if left > right
                    {
                        T temp = array[j];
                        array[j] = array[j + 1];
                        array[j + 1] = temp;
                    }
                }
            }
        }

        /// <summary>
        /// Sorts an array in descending order using Bubble Sort.
        /// </summary>
        /// <typeparam name="T">The type of elements in the array, which must implement IComparable.</typeparam>
        /// <param name="array">The array to sort in descending order.</param>
        /// 

        //Self-comments : •	Sorts an array in decreasing order.
	    //Works exactly like Bubble Sort Ascending, but swaps when the left element is smaller.

        public static void BubbleSortDescending<T>(T[] array) where T : IComparable<T>
        {
            int n = array.Length;
            for (int i = 0; i < n - 1; i++)
            {
                for (int j = 0; j < n - 1 - i; j++) // Move smallest element to the end
                {
                    if (array[j].CompareTo(array[j + 1]) < 0) // Swap if left < right
                    {
                        T temp = array[j];
                        array[j] = array[j + 1];
                        array[j + 1] = temp;
                    }
                }
            }
        }
    }
}
