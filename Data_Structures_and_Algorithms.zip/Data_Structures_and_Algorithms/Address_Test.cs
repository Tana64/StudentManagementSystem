﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Data_Structures_and_Algorithms
{
    /// <summary>
    /// Provides test methods for verifying the functionality of the <see cref="Address"/> class.
    /// </summary>
    public class Address_Test
    {
        /// <summary>
        /// Tests the creation of an <see cref="Address"/> object with specific values.
        /// </summary>
        public void TestAddressCreation()
        {
            var address = new Address("123", "Main Street", "Springfield", "12345", "NY");

            if (address.StreetNum == "123" &&
                address.StreetName == "Main Street" &&
                address.Suburb == "Springfield" &&
                address.Postcode == "12345" &&
                address.State == "NY")
            {
                Console.WriteLine("Test Passed: Address object created successfully with correct values.");
            }
            else
            {
                Console.WriteLine("Test Failed: Address object values are incorrect.");
            }
        }

        /// <summary>
        /// Tests the default constructor of the <see cref="Address"/> class to ensure it initializes with default values.
        /// </summary>
        public void TestDefaultAddress()
        {
            var defaultAddress = new Address();

            if (defaultAddress.StreetNum == "Unknown" &&
                defaultAddress.StreetName == "Unknown" &&
                defaultAddress.Suburb == "Unknown" &&
                defaultAddress.Postcode == "0000" &&
                defaultAddress.State == "Unknown")
            {
                Console.WriteLine("Test Passed: Default Address object has correct default values.");
            }
            else
            {
                Console.WriteLine("Test Failed: Default Address object values are incorrect.");
            }
        }

        /// <summary>
        /// Tests the <see cref="Address.ToString"/> method to verify that it returns the correct formatted address string.
        /// </summary>
        public void TestToStringMethod()
        {
            var address = new Address("456", "Broadway", "Los Angeles", "90001", "CA");
            string expected = "456 Broadway, Los Angeles, CA 90001";

            if (address.ToString() == expected)
            {
                Console.WriteLine("Test Passed: ToString() method returns correct format.");
            }
            else
            {
                Console.WriteLine($"Test Failed: ToString() method returned '{address.ToString()}', expected '{expected}'.");
            }
        }
    }
}
