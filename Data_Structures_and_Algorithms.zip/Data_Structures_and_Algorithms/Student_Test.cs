﻿using System;

namespace Data_Structures_and_Algorithms
{
    /// <summary>
    /// Provides test methods to validate the functionality of the Student class.
    /// </summary>
    public class Student_Test
    {
        /// <summary>
        /// Tests if a Student object can be created successfully.
        /// </summary>
        public void TestStudentObjectCreation()
        {
            try
            {
                var student = new Student();
                Console.WriteLine("Test Passed: Student object created successfully.");
            }
            catch (Exception ex)
            {
                Console.WriteLine($"Test Failed: Error during student object creation - {ex.Message}");
            }
        }

        /// <summary>
        /// Tests if the getters and setters of the Student class work correctly.
        /// </summary>
        public void TestStudentGettersAndSetters()
        {
            var student = new Student();
            student.StudentID = "S123";
            student.Program = "Software Engineering";
            student.DateRegistered = new DateTime(2024, 1, 1);

            if (student.StudentID == "S123" && student.Program == "Software Engineering" && student.DateRegistered == new DateTime(2024, 1, 1))
            {
                Console.WriteLine("Test Passed: Getters and Setters work correctly.");
            }
            else
            {
                Console.WriteLine("Test Failed: Getters and Setters are not working properly.");
            }
        }

        /// <summary>
        /// Tests if the all-argument constructor initializes properties correctly.
        /// </summary>
        public void TestStudentAllArgConstructor()
        {
            var student = new Student("Alice Doe", "alice@example.com", "5555555555", new Address(), "S999", "Data Science", new DateTime(2023, 9, 15), new Subject());

            if (student.StudentID == "S999" && student.Program == "Data Science" && student.DateRegistered == new DateTime(2023, 9, 15))
            {
                Console.WriteLine("Test Passed: All-arg constructor initializes correctly.");
            }
            else
            {
                Console.WriteLine("Test Failed: All-arg constructor initialization is incorrect.");
            }
        }

        /// <summary>
        /// Tests if the parameterless constructor sets default values correctly.
        /// </summary>
        public void TestStudentNoArgConstructor()
        {
            var student = new Student();

            if (student.StudentID == "001214698" && student.Program == "Information Technology")
            {
                Console.WriteLine("Test Passed: No-arg constructor sets default values correctly.");
            }
            else
            {
                Console.WriteLine("Test Failed: No-arg constructor default values are incorrect.");
            }
        }

        /// <summary>
        /// Tests the Equals method by comparing two students with the same StudentID.
        /// </summary>
        public void TestStudentEquals()
        {
            var student1 = new Student("Brian Jones", "brianjones@example.com", "1234567890", new Address(), "S001", "Computer Science", DateTime.Now, new Subject());
            var student2 = new Student("Brian Jones", "brianjones@example.com", "1234567890", new Address(), "S001", "Computer Science", DateTime.Now, new Subject());

            if (student1.Equals(student2))
            {
                Console.WriteLine("Test Passed: student1 equals student2.");
            }
            else
            {
                Console.WriteLine("Test Failed: student1 does not equal student2.");
            }
        }

        /// <summary>
        /// Tests the Equals method by comparing two students with different StudentIDs.
        /// </summary>
        public void TestStudentNotEquals()
        {
            var student1 = new Student("Brian Jones", "brianjones@example.com", "1234567890", new Address(), "S001", "Computer Science", DateTime.Now, new Subject());
            var student2 = new Student("Jane Smith", "jane.smith@example.com", "0987654321", new Address(), "S002", "Mathematics", DateTime.Now, new Subject());

            if (!student1.Equals(student2))
            {
                Console.WriteLine("Test Passed: student1 does not equal student2.");
            }
            else
            {
                Console.WriteLine("Test Failed: student1 equals student2.");
            }
        }

        /// <summary>
        /// Tests the GetHashCode method to ensure students with the same StudentID have the same hash code.
        /// </summary>
        public void TestStudentHashCodes()
        {
            var student1 = new Student("Brian Jones", "brianjones@example.com", "1234567890", new Address(), "S001", "Computer Science", DateTime.Now, new Subject());
            var student2 = new Student("Brian Jones", "brianjones@example.com", "1234567890", new Address(), "S001", "Computer Science", DateTime.Now, new Subject());

            if (student1.GetHashCode() == student2.GetHashCode())
            {
                Console.WriteLine("Test Passed: Hash codes are the same.");
            }
            else
            {
                Console.WriteLine("Test Failed: Hash codes are different.");
            }
        }

        /// <summary>
        /// Tests the equality operator (==) for two students with the same StudentID.
        /// </summary>
        public void TestEqualityOperator()
        {
            var student1 = new Student("Brian Jones", "brianjones@example.com", "1234567890", new Address(), "S001", "Computer Science", DateTime.Now, new Subject());
            var student2 = new Student("Brian Jones", "brianjones@example.com", "1234567890", new Address(), "S001", "Computer Science", DateTime.Now, new Subject());

            if (student1 == student2)
            {
                Console.WriteLine("Test Passed: student1 == student2.");
            }
            else
            {
                Console.WriteLine("Test Failed: student1 != student2.");
            }
        }

        /// <summary>
        /// Tests the inequality operator (!=) for two students with different StudentIDs.
        /// </summary>
        public void TestInequalityOperator()
        {
            var student1 = new Student("Brian Jones", "brianjones@example.com", "1234567890", new Address(), "S001", "Computer Science", DateTime.Now, new Subject());
            var student2 = new Student("Jane Smith", "jane.smith@example.com", "0987654321", new Address(), "S002", "Mathematics", DateTime.Now, new Subject());

            if (student1 != student2)
            {
                Console.WriteLine("Test Passed: student1 != student2.");
            }
            else
            {
                Console.WriteLine("Test Failed: student1 == student2.");
            }
        }
    }
}
