﻿using System;

namespace Data_Structures_and_Algorithms
{
    public class Student_Test
    {

        public void TestStudentObjectCreation()
        {
            try
            {
                var student = new Student();
                Console.WriteLine("Test Passed: Student object created successfully.");
            }
            catch (Exception ex)
            {
                Console.WriteLine($"Test Failed: Error during student object creation - {ex.Message}");
            }
        }

        public void TestStudentGettersAndSetters()
        {
            var student = new Student();
            student.StudentID = "S123";
            student.Program = "Software Engineering";
            student.DateRegistered = new DateTime(2024, 1, 1);

            if (student.StudentID == "S123" && student.Program == "Software Engineering" && student.DateRegistered == new DateTime(2024, 1, 1))
            {
                Console.WriteLine("Test Passed: Getters and Setters work correctly.");
            }
            else
            {
                Console.WriteLine("Test Failed: Getters and Setters are not working properly.");
            }
        }

        public void TestStudentAllArgConstructor()
        {
            var student = new Student("Alice Doe", "alice@example.com", "5555555555", new Address(), "S999", "Data Science", new DateTime(2023, 9, 15));

            if (student.StudentID == "S999" && student.Program == "Data Science" && student.DateRegistered == new DateTime(2023, 9, 15))
            {
                Console.WriteLine("Test Passed: All-arg constructor initializes correctly.");
            }
            else
            {
                Console.WriteLine("Test Failed: All-arg constructor initialization is incorrect.");
            }
        }

        public void TestStudentNoArgConstructor()
        {
            var student = new Student();

            if (student.StudentID == "0000000000" && student.Program == "Unknown")
            {
                Console.WriteLine("Test Passed: No-arg constructor sets default values correctly.");
            }
            else
            {
                Console.WriteLine("Test Failed: No-arg constructor default values are incorrect.");
            }
        }

        public void TestStudentEquals()
        {
            var student1 = new Student("Brian Jones", "brianjones@example.com", "1234567890", new Address(), "S001", "Computer Science", DateTime.Now);
            var student2 = new Student("Brian Jones", "brianjones@example.com", "1234567890", new Address(), "S001", "Computer Science", DateTime.Now);

            if (student1.Equals(student2))
            {
                Console.WriteLine("Test Passed: student1 equals student2.");
            }
            else
            {
                Console.WriteLine("Test Failed: student1 does not equal student2.");
            }
        }

        public void TestStudentNotEquals()
        {
            var student1 = new Student("Brian Jones", "brianjones@example.com", "1234567890", new Address(), "S001", "Computer Science", DateTime.Now);
            var student2 = new Student("Jane Smith", "jane.smith@example.com", "0987654321", new Address(), "S002", "Mathematics", DateTime.Now);

            if (!student1.Equals(student2))
            {
                Console.WriteLine("Test Passed: student1 does not equal student2.");
            }
            else
            {
                Console.WriteLine("Test Failed: student1 equals student2.");
            }
        }

        public void TestStudentHashCodes()
        {
            var student1 = new Student("Brian Jones", "brianjones@example.com", "1234567890", new Address(), "S001", "Computer Science", DateTime.Now);
            var student2 = new Student("Brian Jones", "brianjones@example.com", "1234567890", new Address(), "S001", "Computer Science", DateTime.Now);

            if (student1.GetHashCode() == student2.GetHashCode())
            {
                Console.WriteLine("Test Passed: Hash codes are the same.");
            }
            else
            {
                Console.WriteLine("Test Failed: Hash codes are different.");
            }
        }

        public void TestEqualityOperator()
        {
            var student1 = new Student("Brian Jones", "brianjones@example.com", "1234567890", new Address(), "S001", "Computer Science", DateTime.Now);
            var student2 = new Student("Brian Jones", "brianjones@example.com", "1234567890", new Address(), "S001", "Computer Science", DateTime.Now);

            if (student1 == student2)
            {
                Console.WriteLine("Test Passed: student1 == student2.");
            }
            else
            {
                Console.WriteLine("Test Failed: student1 != student2.");
            }
        }

        public void TestInequalityOperator()
        {
            var student1 = new Student("Brian Jones", "brianjones@example.com", "1234567890", new Address(), "S001", "Computer Science", DateTime.Now);
            var student2 = new Student("Jane Smith", "jane.smith@example.com", "0987654321", new Address(), "S002", "Mathematics", DateTime.Now);

            if (student1 != student2)
            {
                Console.WriteLine("Test Passed: student1 != student2.");
            }
            else
            {
                Console.WriteLine("Test Failed: student1 == student2.");
            }
        }
    }
}
