﻿using NUnit.Framework;
using System;
using Data_Structures_and_Algorithms;


namespace Data_Structures_and_Algorithms.Tests
{
    [TestFixture]  // This attribute marks the class as containing tests
    public class UtilitiesTest1
    {
        private Student[] students;  // Change from List<Student> to Student[]

        [SetUp]  // This method runs before each test
        public void Setup()
        {
            students = new Student[]
            {
                new Student("Lionel Messi", "messi@football.com", "1234567890", new Address(), "10", "Soccer", DateTime.Now),
                new Student("Cristiano Ronaldo", "ronaldo@football.com", "1234567890", new Address(), "07", "Soccer", DateTime.Now),
                new Student("Neymar Jr", "neymar@football.com", "1234567890", new Address(), "11", "Soccer", DateTime.Now),
                new Student("Kylian Mbappé", "mbappe@football.com", "1234567890", new Address(), "29", "Soccer", DateTime.Now),
                new Student("Sergio Ramos", "ramos@football.com", "1234567890", new Address(), "04", "Soccer", DateTime.Now),
                new Student("Kevin De Bruyne", "kevin@football.com", "1234567890", new Address(), "17", "Soccer", DateTime.Now),
                new Student("Mohamed Salah", "salah@football.com", "1234567890", new Address(), "22", "Soccer", DateTime.Now),
                new Student("Luka Modrić", "modric@football.com", "1234567890", new Address(), "18", "Soccer", DateTime.Now),
                new Student("Harry Kane", "kane@football.com", "1234567890", new Address(), "20", "Soccer", DateTime.Now),
                new Student("Robert Lewandowski", "lewandowski@football.com", "1234567890", new Address(), "09", "Soccer", DateTime.Now)
            };
        }

        // **Linear Search Tests**
        [Test]
        public void LinearSearch_StudentFound_ReturnsCorrectIndex()
        {
            // Arrange
            var target = new Student("Neymar Jr", "neymar@football.com", "1234567890", new Address(), "11", "Soccer", DateTime.Now);

            // Act
            int index = Utility.LinearSearchArray(students, target);

            // Assert
            Assert.That(index, Is.EqualTo(2));  // "Neymar Jr" is at index 2
        }

        [Test]
        public void LinearSearch_StudentNotFound_ReturnsNegativeOne()
        {
            // Arrange
            var target = new Student("Zlatan Ibrahimović", "zlatan@football.com", "1234567890", new Address(), "10", "Soccer", DateTime.Now);

            // Act
            int index = Utility.LinearSearchArray(students, target);

            // Assert
            Assert.That(index, Is.EqualTo(-1));  // Zlatan is not in the array
        }

        // **Binary Search Tests**
        [Test]
        public void BinarySearch_StudentFound_ReturnsCorrectIndex()
        {
            // Arrange
            Array.Sort(students, (x, y) => x.StudentID.CompareTo(y.StudentID));  // Ensure array is sorted
            var target = new Student("Neymar Jr", "neymar@football.com", "1234567890", new Address(), "11", "Soccer", DateTime.Now);

            // Act
            int index = Utility.BinarySearchArray(students, target);

            // Assert
            Assert.That(index, Is.EqualTo(2));  // Neymar Jr is at index 2 when sorted
        }

        [Test]
        public void BinarySearch_StudentNotFound_ReturnsNegativeOne()
        {
            // Arrange
            Array.Sort(students, (x, y) => x.StudentID.CompareTo(y.StudentID));  // Ensure array is sorted
            var target = new Student("Zlatan Ibrahimović", "zlatan@football.com", "1234567890", new Address(), "10", "Soccer", DateTime.Now);

            // Act
            int index = Utility.BinarySearchArray(students, target);

            // Assert
            Assert.That(index, Is.EqualTo(-1));  // Zlatan is not in the array
        }

        // **Bubble Sort Tests**
        [Test]
        public void BubbleSort_Ascending_OrderByStudentID()
        {
            // Arrange
            Array.Sort(students, (x, y) => y.StudentID.CompareTo(x.StudentID)); // Start with descending order

            // Act
            Utility.BubbleSortAscending(students);  // Sort in ascending order

            // Assert
            Assert.That(students[0].StudentID, Is.EqualTo("04"));  // First student should have the lowest StudentID
            Assert.That(students[students.Length - 1].StudentID, Is.EqualTo("29"));  // Last student should have the highest StudentID
        }

        [Test]
        public void BubbleSort_Descending_OrderByStudentID()
        {
            // Arrange
            Array.Sort(students, (x, y) => x.StudentID.CompareTo(y.StudentID)); // Start with ascending order

            // Act
            Utility.BubbleSortDescending(students);  // Sort in descending order

            // Assert
            Assert.That(students[0].StudentID, Is.EqualTo("29"));  // First student should have the highest StudentID
            Assert.That(students[students.Length - 1].StudentID, Is.EqualTo("04"));  // Last student should have the lowest StudentID
        }
    }
}
