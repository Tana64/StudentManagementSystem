﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Data_Structures_and_Algorithms
{
    /// <summary>
    /// Represents an enrollment record with details such as enrollment date, grade, and semester.
    /// </summary>
    public class Enrollment
    {
        /// <summary>
        /// The date the student was enrolled.
        /// </summary>
        private DateTime dateEnrolled;

        /// <summary>
        /// The grade assigned for the enrollment.
        /// </summary>
        private string grade;

        /// <summary>
        /// The semester in which the enrollment took place.
        /// </summary>
        private string semester;

        /// <summary>
        /// Counter to track the total number of enrollments.
        /// </summary>
        private static int numEnrollments = 0;

        /// <summary>
        /// Gets or sets the date of enrollment.
        /// </summary>
        public DateTime DateEnrolled
        {
            get { return dateEnrolled; }
            set { dateEnrolled = value; }
        }

        /// <summary>
        /// Gets or sets the grade assigned to the enrollment.
        /// </summary>
        public string Grade
        {
            get { return grade; }
            set { grade = value; }
        }

        /// <summary>
        /// Gets or sets the semester in which the enrollment occurred.
        /// </summary>
        public string Semester
        {
            get { return semester; }
            set { semester = value; }
        }

        /// <summary>
        /// Initializes a new instance of the <see cref="Enrollment"/> class with default values.
        /// </summary>
        public Enrollment() : this(DateTime.Now, "Not Graded", "Unknown") { }

        /// <summary>
        /// Initializes a new instance of the <see cref="Enrollment"/> class with specified values.
        /// </summary>
        /// <param name="dateEnrolled">The date of enrollment.</param>
        /// <param name="grade">The assigned grade.</param>
        /// <param name="semester">The semester of enrollment.</param>
        public Enrollment(DateTime dateEnrolled, string grade, string semester)
        {
            DateEnrolled = dateEnrolled;
            Grade = grade;
            Semester = semester;
            numEnrollments++;
        }

        /// <summary>
        /// Returns a string representation of the enrollment details.
        /// </summary>
        /// <returns>A formatted string containing the enrollment date, grade, and semester.</returns>
        public override string ToString()
        {
            return $"Enrolled: {DateEnrolled.ToShortDateString()}, Grade: {Grade}, Semester: {Semester}";
        }

        /// <summary>
        /// Gets the total number of enrollment instances created.
        /// </summary>
        public static int NumEnrollments
        {
            get { return numEnrollments; }
        }
    }
}
