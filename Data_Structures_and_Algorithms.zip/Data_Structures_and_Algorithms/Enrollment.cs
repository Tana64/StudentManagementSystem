﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;


namespace Data_Structures_and_Algorithms
{
    /// <summary>
    /// Represents an enrollment record with details such as enrollment date, grade, and semester.
    /// </summary>
    public class Enrollment
    {
        // Constants for default values
        private const string DEFAULT_GRADE = "Not Graded";
        private const string DEFAULT_SEMESTER = "Unknown Semester";
        private static readonly DateTime DEFAULT_ENROLLMENT_DATE = DateTime.Now;


        /// <summary>
        /// Gets or sets the date of enrollment.
        /// </summary>
        public DateTime DateEnrolled { get; set; }

        /// <summary>
        /// Gets or sets the grade assigned to the enrollment.
        /// </summary>
        public string Grade { get; set; }

        /// <summary>
        /// Gets or sets the semester in which the enrollment occurred.
        /// </summary>
        public string Semester { get; set; }


        public Subject Subject { get; set; }

        /// <summary>
        /// Initializes a new instance of the <see cref="Enrollment"/> class with default values.
        /// </summary>
        public Enrollment() : this(DEFAULT_ENROLLMENT_DATE, DEFAULT_GRADE, DEFAULT_SEMESTER, new Subject()) { }

        /// <summary>
        /// Initializes a new instance of the <see cref="Enrollment"/> class with specified values.
        /// </summary>
        public Enrollment(DateTime dateEnrolled, string grade, string semester, Subject subject)
        {
            DateEnrolled = dateEnrolled;
            Grade = grade;
            Semester = semester;
            Subject = subject;
        }

        /// <summary>
        /// Returns a string representation of the enrollment details.
        /// </summary>
        public override string ToString()
        {
            return $"Enrolled: {DateEnrolled.ToShortDateString()}, Grade: {Grade}, Semester: {Semester},  Subject: {Subject.SubjectName}";
        }
    }
}
