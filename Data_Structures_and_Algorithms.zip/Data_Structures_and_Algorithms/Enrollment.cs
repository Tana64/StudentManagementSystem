﻿using System;

namespace Data_Structures_and_Algorithms
{
    /// <summary>
    /// Represents an enrollment record with details such as enrollment date, grade, and semester.
    /// </summary>
    public class Enrollment
    {
        // Constants for default values
        private const string DEFAULT_GRADE = "Not Graded";
        private const string DEFAULT_SEMESTER = "Unknown Semester";
        private static readonly DateTime DEFAULT_ENROLLMENT_DATE = DateTime.Now;
        private static readonly Student DEFAULT_STUDENT = new Student();
        private static readonly Subject DEFAULT_SUBJECT = new Subject();

        /// <summary>
        /// Gets or sets the date of enrollment.
        /// </summary>
        public DateTime DateEnrolled { get; set; }

        /// <summary>
        /// Gets or sets the grade assigned to the enrollment.
        /// </summary>
        public string Grade { get; set; }

        /// <summary>
        /// Gets or sets the semester in which the enrollment occurred.
        /// </summary>
        public string Semester { get; set; }

        /// <summary>
        /// Gets or sets the student associated with this enrollment.
        /// </summary>
        public Student Student { get; set; }

        /// <summary>
        /// Gets or sets the subject associated with this enrollment.
        /// </summary>
        public Subject Subject { get; set; }

        /// <summary>
        /// Initializes a new instance of the <see cref="Enrollment"/> class with default values.
        /// </summary>
        public Enrollment()
            : this(DEFAULT_ENROLLMENT_DATE, DEFAULT_GRADE, DEFAULT_SEMESTER, DEFAULT_STUDENT, DEFAULT_SUBJECT) { }

        /// <summary>
        /// Initializes a new instance of the <see cref="Enrollment"/> class with specified values.
        /// </summary>
        public Enrollment(DateTime dateEnrolled, string grade, string semester, Student student, Subject subject)
        {
            DateEnrolled = dateEnrolled;
            Grade = grade;
            Semester = semester;
            Student = student;
            Subject = subject;
        }

        /// <summary>
        /// Returns a string representation of the enrollment details.
        /// </summary>
        public override string ToString()
        {
            return $"Enrolled: {DateEnrolled.ToShortDateString()}, Grade: {Grade}, Semester: {Semester}, Student: {Student.Name}, Subject: {Subject.SubjectName}";
        }
    }
}
