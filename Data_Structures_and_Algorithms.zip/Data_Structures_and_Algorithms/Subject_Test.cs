﻿using System;

namespace Data_Structures_and_Algorithms
{
    /// <summary>
    /// A test class for verifying the functionality of the Subject class.
    /// </summary>
    public class Subject_Test
    {
        /// <summary>
        /// Tests if a Subject object can be created without errors.
        /// </summary>
        public void TestSubjectObjectCreation()
        {
            try
            {
                var subject = new Subject();
                Console.WriteLine("Test Passed: Subject object created successfully.");
            }
            catch (Exception ex)
            {
                Console.WriteLine($"Test Failed: Error during Subject object creation - {ex.Message}");
            }
        }

        /// <summary>
        /// Tests the getters and setters of the Subject class.
        /// </summary>
        public void TestSubjectGettersAndSetters()
        {
            var subject = new Subject
            {
                SubjectCode = "CS101",
                SubjectName = "Computer Science",
                Cost = 500.0
            };

            if (subject.SubjectCode == "CS101" && subject.SubjectName == "Computer Science" && subject.Cost == 500.0)
            {
                Console.WriteLine("Test Passed: Getters and Setters work correctly.");
            }
            else
            {
                Console.WriteLine("Test Failed: Getters and Setters are not working properly.");
            }
        }

        /// <summary>
        /// Tests whether the all-argument constructor initializes the Subject object correctly.
        /// </summary>
        public void TestSubjectAllArgConstructor()
        {
            var subject = new Subject("MTH101", "Mathematics", 400.0);

            if (subject.SubjectCode == "MTH101" && subject.SubjectName == "Mathematics" && subject.Cost == 400.0)
            {
                Console.WriteLine("Test Passed: All-arg constructor initializes correctly.");
            }
            else
            {
                Console.WriteLine("Test Failed: All-arg constructor initialization is incorrect.");
            }
        }

        /// <summary>
        /// Tests whether the no-argument constructor sets default values correctly.
        /// </summary>
        public void TestSubjectNoArgConstructor()
        {
            var subject = new Subject();

            if (subject.SubjectCode == "SS01234" && subject.SubjectName == "Default Subject" && subject.Cost == 0.0)
            {
                Console.WriteLine("Test Passed: No-arg constructor sets default values correctly.");
            }
            else
            {
                Console.WriteLine("Test Failed: No-arg constructor default values are incorrect.");
            }
        }

        /// <summary>
        /// Tests the ToString() method to ensure it provides the correct output format.
        /// </summary>
        public void TestSubjectToString()
        {
            var subject = new Subject("PHY101", "Physics", 450.0);
            string expectedOutput = "PHY101: Physics, Cost: $450";

            if (subject.ToString() == expectedOutput)
            {
                Console.WriteLine("Test Passed: ToString() method works correctly.");
            }
            else
            {
                Console.WriteLine($"Test Failed: ToString() output is incorrect. Expected '{expectedOutput}', but got '{subject.ToString()}'.");
            }
        }
    }
}
