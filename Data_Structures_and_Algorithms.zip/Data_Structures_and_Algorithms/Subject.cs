﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Data_Structures_and_Algorithms
{
    /// <summary>
    /// Represents a subject with a unique code, name, and cost.
    /// </summary>
    public class Subject
    {
        // Private fields
        private string subjectCode; // Stores the subject code
        private string subjectName; // Stores the subject name
        private double cost; // Stores the cost of the subject
        private static int numSubjects = 0; // Static counter to track the number of subjects

        /// <summary>
        /// Gets or sets the subject code.
        /// </summary>
        public string SubjectCode
        {
            get { return subjectCode; }
            set { subjectCode = value; }
        }

        /// <summary>
        /// Gets or sets the subject name.
        /// </summary>
        public string SubjectName
        {
            get { return subjectName; }
            set { subjectName = value; }
        }

        /// <summary>
        /// Gets or sets the cost of the subject.
        /// </summary>
        public double Cost
        {
            get { return cost; }
            set { cost = value; }
        }

        /// <summary>
        /// Default constructor that initializes a subject with default values.
        /// </summary>
        public Subject() : this("Unknown", "Unknown", 0.0) { }

        /// <summary>
        /// Parameterized constructor that initializes a subject with given values.
        /// </summary>
        /// <param name="subjectCode">The unique code of the subject.</param>
        /// <param name="subjectName">The name of the subject.</param>
        /// <param name="cost">The cost of the subject.</param>
        public Subject(string subjectCode, string subjectName, double cost)
        {
            SubjectCode = subjectCode;
            SubjectName = subjectName;
            Cost = cost;
            numSubjects++; // Increment the count of subjects created
        }

        /// <summary>
        /// Returns a string representation of the subject.
        /// </summary>
        /// <returns>A formatted string containing the subject's details.</returns>
        public override string ToString()
        {
            return $"{SubjectCode}: {SubjectName}, Cost: ${Cost}";
        }

        /// <summary>
        /// Gets the total number of subjects created.
        /// </summary>
        public static int NumSubjects
        {
            get { return numSubjects; }
        }
    }
}
