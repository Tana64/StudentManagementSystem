﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Data_Structures_and_Algorithms
{
    public class Person
    {
        private string name;
        private string email;
        private string phoneNumber;
        private Address address;
        private static int numPersons = 0;

        public string Name { get { return name; } set { name = value; } }
        public string Email { get { return email; } set { email = value; } }
        public string PhoneNumber { get { return phoneNumber; } set { phoneNumber = value; } }
        public Address Address { get { return address; } set { address = value; } }

        public Person() : this("Unknown", "Unknown", "0000000000", new Address()) { }
        public Person(string name, string email, string phoneNumber, Address address)
        {
            Name = name;
            Email = email;
            PhoneNumber = phoneNumber;
            Address = address;
            numPersons++;
        }

        public override string ToString()
        {
            return $"{Name} ({Email}, {PhoneNumber}), Address: {Address}";
        }

        public static int NumPersons { get { return numPersons; } }


    }
}
