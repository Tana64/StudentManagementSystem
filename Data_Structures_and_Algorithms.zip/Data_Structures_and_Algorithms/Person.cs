﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;


namespace Data_Structures_and_Algorithms
{
    /// <summary>
    /// Represents a person with basic contact information and an address.
    /// </summary>
    public class Person
    {
        // Constants for default values
        protected const string DEFAULT_NAME = "Unknown";
        protected const string DEFAULT_EMAIL = "Unknown";
        protected const string DEFAULT_PHONE = "1234567891";
        

        private static int numPersons = 0;

        /// <summary>
        /// Gets or sets the person's name.
        /// </summary>
        public string Name { get; set; }

        /// <summary>
        /// Gets or sets the person's email.
        /// </summary>
        public string Email { get; set; }

        /// <summary>
        /// Gets or sets the person's phone number.
        /// </summary>
        public string PhoneNumber { get; set; }

        /// <summary>
        /// Gets or sets the person's address.
        /// </summary>
        public Address Address { get; set; }

        /// <summary>
        /// Initializes a new instance of the <see cref="Person"/> class with default values.
        /// </summary>
        public Person() : this(DEFAULT_NAME, DEFAULT_EMAIL, DEFAULT_PHONE, new Address()) { }

        /// <summary>
        /// Initializes a new instance of the <see cref="Person"/> class with specified values.
        /// </summary>
        public Person(string name, string email, string phoneNumber, Address address)
        {
            Name = name;
            Email = email;
            PhoneNumber = phoneNumber;
            Address = address;
            numPersons++;
        }

        /// <summary>
        /// Returns a string representation of the person's details.
        /// </summary>
        public override string ToString()
        {
            return $"{Name} ({Email}, {PhoneNumber}), Address: {Address}";
        }

        /// <summary>
        /// Gets the total number of persons created.
        /// </summary>
        public static int NumPersons => numPersons;
    }
}
