﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;


namespace Data_Structures_and_Algorithms
{
    /// <summary>
    /// A test class for verifying the functionality of the Person class.
    /// </summary>
    public class Person_Test
    {
        /// <summary>
        /// Tests if a Person object can be created without errors.
        /// </summary>
        public void TestPersonObjectCreation()
        {
            try
            {
                var person = new Person();
                Console.WriteLine("Test Passed: Person object created successfully.");
            }
            catch (Exception ex)
            {
                Console.WriteLine($"Test Failed: Error during Person object creation - {ex.Message}");
            }
        }

        /// <summary>
        /// Tests the getters and setters of the Person class.
        /// </summary>
        public void TestPersonGettersAndSetters()
        {
            var person = new Person();
            person.Name = "John Doe";
            person.Email = "johndoe@example.com";
            person.PhoneNumber = "1234567890";
            person.Address = new Address("12", "Maple Street", "New York", "10001", "NY");

            if (person.Name == "John Doe" && person.Email == "johndoe@example.com" && person.PhoneNumber == "1234567890")
            {
                Console.WriteLine("Test Passed: Getters and Setters work correctly.");
            }
            else
            {
                Console.WriteLine("Test Failed: Getters and Setters are not working properly.");
            }
        }

        /// <summary>
        /// Tests whether the all-argument constructor initializes the Person object correctly.
        /// </summary>
        public void TestPersonAllArgConstructor()
        {
            var address = new Address("45", "Pine Street", "San Francisco", "94107", "CA");
            var person = new Person("Alice Doe", "alice@example.com", "5555555555", address);

            if (person.Name == "Alice Doe" && person.Email == "alice@example.com" && person.PhoneNumber == "5555555555" && person.Address == address)
            {
                Console.WriteLine("Test Passed: All-arg constructor initializes correctly.");
            }
            else
            {
                Console.WriteLine("Test Failed: All-arg constructor initialization is incorrect.");
            }
        }

        /// <summary>
        /// Tests whether the no-argument constructor sets default values correctly.
        /// </summary>
        public void TestPersonNoArgConstructor()
        {
            var person = new Person();

            if (person.Name == "Unknown" && person.Email == "Unknown" && person.PhoneNumber == "1234567891")
            {
                Console.WriteLine("Test Passed: No-arg constructor sets default values correctly.");
            }
            else
            {
                Console.WriteLine("Test Failed: No-arg constructor default values are incorrect.");
            }
        }

        /// <summary>
        /// Tests the ToString() method to ensure it provides the correct output format.
        /// </summary>
        public void TestPersonToString()
        {
            var address = new Address("789", "Sunset Blvd", "Los Angeles", "90001", "CA");
            var person = new Person("John Doe", "johndoe@example.com", "1234567890", address);
            string expectedOutput = $"{person.Name} ({person.Email}, {person.PhoneNumber}), Address: {address}";

            if (person.ToString() == expectedOutput)
            {
                Console.WriteLine("Test Passed: ToString() method works correctly.");
            }
            else
            {
                Console.WriteLine($"Test Failed: ToString() method returned '{person.ToString()}', expected '{expectedOutput}'.");
            }
        }

        /// <summary>
        /// Tests whether the static NumPersons property correctly tracks the number of Person instances.
        /// </summary>
        public void TestNumPersons()
        {
            int beforeCreation = Person.NumPersons;
            var person1 = new Person();
            var person2 = new Person();

            if (Person.NumPersons == beforeCreation + 2)
            {
                Console.WriteLine("Test Passed: NumPersons increments correctly.");
            }
            else
            {
                Console.WriteLine("Test Failed: NumPersons is incorrect.");
            }
        }
    }
}

