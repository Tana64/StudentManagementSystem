﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Data_Structures_and_Algorithms
{
    class Program
    {
        public static void Main(string[] args)
        {
            

            // 1. Testing the Student class
            var test = new Student_Test();

            Console.WriteLine("Running Student Class Tests...");
            test.TestStudentObjectCreation();
            test.TestStudentGettersAndSetters();
            test.TestStudentAllArgConstructor();
            test.TestStudentNoArgConstructor();
            test.TestStudentEquals();
            test.TestStudentNotEquals();
            test.TestStudentHashCodes();
            test.TestEqualityOperator();
            test.TestInequalityOperator();


            //2. Testing the Address Class
            Address_Test addressTest = new Address_Test();

            Console.WriteLine("Running Address Class Tests...");
            addressTest.TestAddressCreation();
            addressTest.TestDefaultAddress();
            addressTest.TestToStringMethod();

            //3. Testing the Enrollment Class
            Enrolment_Tests enrolmentTest = new Enrolment_Tests();

            Console.WriteLine("Running Enrollment Class Tests...");
            enrolmentTest.TestEnrollmentCreation();
            enrolmentTest.TestDefaultEnrollment();
            enrolmentTest.TestToStringMethod();

            //4. Testing the Person Class
            var personTest = new Person_Test();

            Console.WriteLine("Running Person Class Tests...");
            personTest.TestPersonObjectCreation();
            personTest.TestPersonGettersAndSetters();
            personTest.TestPersonAllArgConstructor();
            personTest.TestPersonNoArgConstructor();
            personTest.TestPersonToString();
            personTest.TestNumPersons();

            //5.Test the Subject class
            var subjectTest = new Subject_Test();

            Console.WriteLine("Running Subject Class Tests...");
            subjectTest.TestSubjectObjectCreation();
            subjectTest.TestSubjectGettersAndSetters();
            subjectTest.TestSubjectAllArgConstructor();
            subjectTest.TestSubjectNoArgConstructor();
            subjectTest.TestSubjectToString();
            subjectTest.TestNumSubjects();


            // Pause to view the output
            Console.WriteLine("\nPress any key to exit...");
            Console.ReadKey();
        }
    }
}
