﻿using System;

namespace Data_Structures_and_Algorithms
{
    class Program
    {
        public static void Main(string[] args)
        {
            Console.WriteLine("Starting Test Execution...\n");

            // 1. Testing the Student class
            var studentTest = new Student_Test();
            Console.WriteLine("Running Student Class Tests...");
            studentTest.TestStudentObjectCreation();
            studentTest.TestStudentGettersAndSetters();
            studentTest.TestStudentAllArgConstructor();
            studentTest.TestStudentNoArgConstructor();
            studentTest.TestStudentEquals();
            studentTest.TestStudentNotEquals();
            studentTest.TestStudentHashCodes();

            // Ensure these methods exist in Student_Test before calling them
            // Remove these if they are not implemented
            // studentTest.TestEqualityOperator();
            // studentTest.TestInequalityOperator();

            Console.WriteLine("\n---------------------------------\n");

            // 2. Testing the Address Class
            var addressTest = new Address_Test();
            Console.WriteLine("Running Address Class Tests...");
            addressTest.TestAddressCreation();
            addressTest.TestDefaultAddress();
            addressTest.TestToStringMethod();

            Console.WriteLine("\n---------------------------------\n");

            // 3. Testing the Enrollment Class
            var enrollmentTest = new Enrolment_Tests();  // Use correct class name

            Console.WriteLine("Running Enrollment Class Tests...");
            enrollmentTest.TestEnrollmentObjectCreation();
            enrollmentTest.TestDefaultEnrollment();
            enrollmentTest.TestEnrollmentToString();  // Ensure this matches method name in the test class

            Console.WriteLine("\n---------------------------------\n");

            // 4. Testing the Person Class
            var personTest = new Person_Test();
            Console.WriteLine("Running Person Class Tests...");
            personTest.TestPersonObjectCreation();
            personTest.TestPersonGettersAndSetters();
            personTest.TestPersonAllArgConstructor();
            personTest.TestPersonNoArgConstructor();
            personTest.TestPersonToString();
            personTest.TestNumPersons();

            Console.WriteLine("\n---------------------------------\n");

            // 5. Testing the Subject Class
            var subjectTest = new Subject_Test();
            Console.WriteLine("Running Subject Class Tests...");
            subjectTest.TestSubjectObjectCreation();
            subjectTest.TestSubjectGettersAndSetters();
            subjectTest.TestSubjectAllArgConstructor();
            subjectTest.TestSubjectNoArgConstructor();
            subjectTest.TestSubjectToString();

            Console.WriteLine("\n---------------------------------\n");

            // Pause to view the output
            Console.WriteLine("\nAll tests completed successfully!");
            Console.WriteLine("Press any key to exit...");
            Console.ReadKey();
        }
    }
}
