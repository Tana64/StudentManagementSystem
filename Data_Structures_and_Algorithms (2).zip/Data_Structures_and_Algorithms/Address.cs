﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Data_Structures_and_Algorithms
{
    /// <summary>
    /// Represents an address with details such as street number, street name, suburb, postcode, and state.
    /// </summary>
    public class Address
    {
        private const string DEFAULT_STREET_NUM = "Unknown";
        private const string DEFAULT_STREET_NAME = "Unknown";
        private const string DEFAULT_SUBURB = "Unknown";
        private const string DEFAULT_POSTCODE = "0000";
        private const string DEFAULT_STATE = "Unknown";

        private string streetNum;
        private string streetName;
        private string suburb;
        private string postcode;
        private string state;

        private static int numAddresses = 0;

        public string StreetNum { get => streetNum; set => streetNum = value; }
        public string StreetName { get => streetName; set => streetName = value; }
        public string Suburb { get => suburb; set => suburb = value; }
        public string Postcode { get => postcode; set => postcode = value; }
        public string State { get => state; set => state = value; }

        public Address() : this(DEFAULT_STREET_NUM, DEFAULT_STREET_NAME, DEFAULT_SUBURB, DEFAULT_POSTCODE, DEFAULT_STATE) { }

        public Address(string streetNum, string streetName, string suburb, string postcode, string state)
        {
            StreetNum = streetNum;
            StreetName = streetName;
            Suburb = suburb;
            Postcode = postcode;
            State = state;
            numAddresses++;
        }

        public override string ToString()
        {
            return $"{StreetNum} {StreetName}, {Suburb}, {State} {Postcode}";
        }

        public static int NumAddresses => numAddresses;
    }
}
