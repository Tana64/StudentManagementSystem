﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Data_Structures_and_Algorithms
{
    /// <summary>
    /// Represents a subject with a unique code, name, and cost.
    /// </summary>
    public class Subject
    {
        // Constants for default values
        private const string DEFAULT_SUBJECT_CODE = "SS01234";
        private const string DEFAULT_SUBJECT_NAME = "Default Subject";
        private const double DEFAULT_COST = 0.0;

        /// <summary>
        /// Gets or sets the subject code.
        /// </summary>
        public string SubjectCode { get; set; }

        /// <summary>
        /// Gets or sets the subject name.
        /// </summary>
        public string SubjectName { get; set; }

        /// <summary>
        /// Gets or sets the cost of the subject.
        /// </summary>
        public double Cost { get; set; }

        /// <summary>
        /// Initializes a new instance of the <see cref="Subject"/> class with default values.
        /// </summary>
        public Subject() : this(DEFAULT_SUBJECT_CODE, DEFAULT_SUBJECT_NAME, DEFAULT_COST) { }

        /// <summary>
        /// Initializes a new instance of the <see cref="Subject"/> class with specified values.
        /// </summary>
        public Subject(string subjectCode, string subjectName, double cost)
        {
            SubjectCode = subjectCode;
            SubjectName = subjectName;
            Cost = cost;
        }

        /// <summary>
        /// Returns a string representation of the subject.
        /// </summary>
        public override string ToString()
        {
            return $"{SubjectCode}: {SubjectName}, Cost: ${Cost}";
        }
    }
}
