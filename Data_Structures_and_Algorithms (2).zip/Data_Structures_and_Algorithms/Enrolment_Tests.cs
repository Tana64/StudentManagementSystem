﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;


namespace Data_Structures_and_Algorithms
{
    /// <summary>
    /// Provides test methods to validate the functionality of the Student and Enrollment classes.
    /// </summary>
    public class Enrolment_Tests
    {
        /// <summary>
        /// Tests if a Student object can be created successfully.
        /// </summary>
        public void TestStudentObjectCreation()
        {
            try
            {
                var student = new Student();
                Console.WriteLine("Test Passed: Student object created successfully.");
            }
            catch (Exception ex)
            {
                Console.WriteLine($"Test Failed: Error during student object creation - {ex.Message}");
            }
        }

        /// <summary>
        /// Tests if the getters and setters of the Student class work correctly.
        /// </summary>
        public void TestStudentGettersAndSetters()
        {
            var student = new Student();
            student.StudentID = "S123";
            student.Program = "Software Engineering";
            student.DateRegistered = new DateTime(2024, 1, 1);

            if (student.StudentID == "S123" && student.Program == "Software Engineering" && student.DateRegistered == new DateTime(2024, 1, 1))
            {
                Console.WriteLine("Test Passed: Getters and Setters work correctly.");
            }
            else
            {
                Console.WriteLine("Test Failed: Getters and Setters are not working properly.");
            }
        }

        /// <summary>
        /// Tests if an Enrollment object can be created successfully.
        /// </summary>
        public void TestEnrollmentObjectCreation()
        {
            try
            {
                var student = new Student();
                var subject = new Subject();
                var enrollment = new Enrollment(DateTime.Now, "A", "Spring 2024", student, subject);
                Console.WriteLine("Test Passed: Enrollment object created successfully.");
            }
            catch (Exception ex)
            {
                Console.WriteLine($"Test Failed: Error during enrollment object creation - {ex.Message}");
            }
        }

        /// <summary>
        /// Tests the default constructor of the Enrollment class.
        /// </summary>
        public void TestDefaultEnrollment()
        {
            var defaultEnrollment = new Enrollment();

            if (defaultEnrollment.Grade == "Not Graded" &&
                defaultEnrollment.Semester == "Unknown Semester" &&
                defaultEnrollment.Student != null &&
                defaultEnrollment.Subject != null)
            {
                Console.WriteLine("Test Passed: Default Enrollment object has correct default values.");
            }
            else
            {
                Console.WriteLine("Test Failed: Default Enrollment object values are incorrect.");
            }
        }

        /// <summary>
        /// Tests the ToString method of the Enrollment class.
        /// </summary>
        public void TestEnrollmentToString()
        {
            var student = new Student { Name = "Alice Doe" };
            var subject = new Subject { SubjectName = "Data Structures" };
            var enrollment = new Enrollment(new DateTime(2024, 2, 1), "B+", "Fall 2024", student, subject);

            string expected = $"Enrolled: {new DateTime(2024, 2, 1).ToShortDateString()}, Grade: B+, Semester: Fall 2024, Student: Alice Doe, Subject: Data Structures";

            if (enrollment.ToString() == expected)
            {
                Console.WriteLine("Test Passed: ToString() method returns correct format.");
            }
            else
            {
                Console.WriteLine($"Test Failed: ToString() method returned '{enrollment.ToString()}', expected '{expected}'.");
            }
        }
    }
}
